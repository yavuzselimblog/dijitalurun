<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Products extends CI_Controller{

    public function index(){

        
        $perPage        = 6;
        $productcount   = $this->Common_model->getcount(['urun_durum'=>1],'urunler');
        $pageSegment    = ($this->uri->segment(2)) ? $this->uri->segment(2) : 1;
        $pkCount        = ($pageSegment - 1) * $perPage;

        $links       = paginationHelper(
            base_url('products'),
            $productcount,
            $perPage,
            2,
            TRUE,['class' => 'page-link']
        );

        $viewData      = array(
            "setting"      => $this->Common_model->get(['id'=>1],'ayarlar'),
            "productlist"  => $this->Common_model->getLimitAll(['urun_durum'=>1],$perPage,$pkCount,'urunler','urun_id','DESC'),
            "productcount" => $productcount,
            "productlinks" => $links,

            "categories"   => $this->Common_model->getAll(['katdurum'=>1],'kategoriler'),

            'social'       => $this->Common_model->getAll(['sosdurum'=>1],'sosyalmedyalar'),
            'pages'        => $this->Common_model->getAll(['sayfadurum'=>1],'sayfalar'),
            'popular'      => $this->Common_model->getLimitAll(['urun_durum'=>1],8,0,'urunler','urun_goruntulenme','DESC'),
            'popblog'      => $this->Common_model->getLimitAll(['blogdurum'=>1],4,0,'blog','bloggoruntulenme','DESC'),
        );

        $this->load->view('default/products_view',$viewData);

    }

    public function detail($par1,$par2){
        if(!$par1 || !$par2){
            redirect(base_url());
        }

        $query = $this->Common_model->get([
            'urun_durum'=>1,
            'urun_kodu' =>$par2,
            'urun_sef'  =>$par1
        ],'urunler');

        if($query){

            ##ürün görüntülenmesini arttır ##
            $views = @$_COOKIE[$query->urun_kodu];
            if(!$views){
                $plus = $query->urun_goruntulenme + 1;
                $this->db->query("UPDATE urunler SET urun_goruntulenme='$plus' WHERE urun_kodu='$query->urun_kodu'");
                setcookie($query->urun_kodu,'1',time() + 3600);
            }
            ##ürün görüntülenmesini arttır ##

            $viewData = array(
                'product'        => $query,
                'productcomment' => $this->Common_model->getAll(['yorumurun'=>$query->urun_kodu,'yorumdurum'=>1],'yorumlar'),
                'productimage'   => $this->Common_model->getAll(['resurun'=>$query->urun_kodu],'urunresimler'),
                'productskill'   => $this->Common_model->getAll(['ozurun'=>$query->urun_kodu],'urunozellikler'),
                'productsell'    => $this->Common_model->getcount(['sipurun'=>$query->urun_kodu,'sipdurum'=>'tamamlandi'],'siparisler'),
                'related'        => $this->Common_model->getLimitAll(['urun_kategori'=>$query->urun_kategori,'urun_kodu !='=>$query->urun_kodu],5,0,'urunler','urun_goruntulenme','Desc'),

                "setting"        => $this->Common_model->get(['id'=>1],'ayarlar'),
                'social'         => $this->Common_model->getAll(['sosdurum'=>1],'sosyalmedyalar'),
                'pages'          => $this->Common_model->getAll(['sayfadurum'=>1],'sayfalar'),
                'popular'        => $this->Common_model->getLimitAll(['urun_durum'=>1],8,0,'urunler','urun_goruntulenme','DESC'),
                'popblog'        => $this->Common_model->getLimitAll(['blogdurum'=>1],4,0,'blog','bloggoruntulenme','DESC'),
            );

            $this->load->view('default/productdetail_view',$viewData);

        }else{
            redirect(base_url()); 
        }

    }

}

?>
